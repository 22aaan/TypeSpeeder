# TypeSpeeder

The warnings are written in english and make sure that you read the warnings carefully.

## Update 1 of 3
One file is now added to the project:

* MenuTest.java



## Update 2 of 3
Three files are now added to the project:

* ChallengePerformanceTest.java
* ChallengeTest.java
* MenuPerformanceTest.java

## Update 3 of 3
Two files are now added to the project:

* NewsLetterTest.java
* PatchTest.java
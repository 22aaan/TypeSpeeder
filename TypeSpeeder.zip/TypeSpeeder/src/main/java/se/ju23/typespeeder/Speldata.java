package se.ju23.typespeeder;

import jakarta.persistence.*;

@Entity
@Table(name = "speldata")
public class Speldata {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "spel_dataid", nullable = false)
    private Long spelDataId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "anvandarid", insertable = false, updatable = false)
    private Anvandare anvandare;
    @Column(name = "niva")
    private Integer niva;

    @Column(name = "tid")
    private Long tid;

    @Column(name = "ratta_svar")
    private Integer rattaSvar;

    @Column(name = "svariordning")
    private String svarIOrdning;

    @Column(name = "is_correct")
    private Boolean isCorrect;
    // Getters och setters
    public Long getSpelDataId() {
        return spelDataId;
    }

    public void setSpelDataId(Long spelDataId) {
        this.spelDataId = spelDataId;
    }

    public Anvandare getAnvandare() {
        return anvandare;
    }

    public void setAnvandare(Anvandare anvandare) {
        this.anvandare = anvandare;
    }
    public Integer getNiva() {
        return niva;
    }

    public void setNiva(Integer niva) {
        this.niva = niva;
    }

    public Long getTid() {
        return tid;
    }

    public void setTid(Long tid) {
        this.tid = tid;
    }

    public Integer getRattaSvar() {
        return rattaSvar;
    }

    public void setRattaSvar(Integer rattaSvar) {
        this.rattaSvar = rattaSvar;
    }

    public String getSvarIOrdning() {
        return svarIOrdning;
    }

    public void setSvarIOrdning(String svarIOrdning) {
        this.svarIOrdning = svarIOrdning;
    }

    public Boolean getIsCorrect() {
        return isCorrect;
    }

    public void setIsCorrect(Boolean isCorrect) {
        this.isCorrect = isCorrect;
    }
}

package se.ju23.typespeeder;

public class NewsLetter {
}

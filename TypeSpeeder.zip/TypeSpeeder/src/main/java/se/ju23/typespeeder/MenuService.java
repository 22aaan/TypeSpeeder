package se.ju23.typespeeder;

import java.util.List;

public interface MenuService {
    List<String> getMenuOptions();
    void displayMenu();
}